LSP_CF()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_url("diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com", 
		"URL=https://diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t72.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://translate.googleapis.com/translate_a/l?client=chrome&hl=en&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		LAST);

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t73.inf", 
		"Mode=HTML", 
		LAST);

	web_submit_data("sso", 
		"Action=http://10.26.156.125:50000/saml2/idp/sso", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t74.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=SAMLRequest", "Value="
		"PEF1dGhuUmVxdWVzdCB4bWxucz0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOnByb3RvY29sIiB4bWxuczpuczI9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDphc3NlcnRpb24iIHhtbG5zOm5zMz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC8wOS94bWxkc2lnIyIgeG1sbnM6bnM0PSJodHRwOi8vd3d3LnczLm9yZy8yMDAxLzA0L3htbGVuYyMiIEFzc2VydGlvbkNvbnN1bWVyU2VydmljZVVSTD0iaHR0cHM6Ly9kaXBlcmYtd2YxZjUyMjE0LmRpc3BhdGNoZXIuaW50LnNhcC5oYW5hLm9uZGVtYW5kLmNvbS8iIERlc3RpbmF0aW9uPSJodHRwOi8vMTAuMjYuMTU2LjEyNTo1MDAwMC9zYW1sMi9pZHAvc3NvIiBGb3JjZUF1dGhuPSJ0cnVlIiBJRD0iU2Y1OT"
		"M1OWJkLWJiMDctNGFlYi05ZDYyLTFkNjcyMDU3OTkzOS15UFlLakxYalRLZXN4ak9XU2ZTNlRLcGx5UEE4UXJacGFpNjR6al9oQUhzIiBJc3N1ZUluc3RhbnQ9IjIwMTctMDktMjZUMTE6MTk6NDEuNzQ0WiIgVmVyc2lvbj0iMi4wIj48bnMyOklzc3Vlcj5odHRwczovL25lby5vbmRlbWFuZC5jb20vb2RwZXJmL2VwPC9uczI6SXNzdWVyPjxkczpTaWduYXR1cmUgeG1sbnM6ZHM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvMDkveG1sZHNpZyMiPjxkczpTaWduZWRJbmZvPjxkczpDYW5vbmljYWxpemF0aW9uTWV0aG9kIEFsZ29yaXRobT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS8xMC94bWwtZXhjLWMxNG4jIi8+"
		"PGRzOlNpZ25hdHVyZU1ldGhvZCBBbGdvcml0aG09Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvMDkveG1sZHNpZyNyc2Etc2hhMSIvPjxkczpSZWZlcmVuY2UgVVJJPSIjU2Y1OTM1OWJkLWJiMDctNGFlYi05ZDYyLTFkNjcyMDU3OTkzOS15UFlLakxYalRLZXN4ak9XU2ZTNlRLcGx5UEE4UXJacGFpNjR6al9oQUhzIj48ZHM6VHJhbnNmb3Jtcz48ZHM6VHJhbnNmb3JtIEFsZ29yaXRobT0iaHR0cDovL3d3dy53My5vcmcvMjAwMC8wOS94bWxkc2lnI2VudmVsb3BlZC1zaWduYXR1cmUiLz48ZHM6VHJhbnNmb3JtIEFsZ29yaXRobT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS8xMC94bWwtZXhjLWMxNG4jIi8+"
		"PC9kczpUcmFuc2Zvcm1zPjxkczpEaWdlc3RNZXRob2QgQWxnb3JpdGhtPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwLzA5L3htbGRzaWcjc2hhMSIvPjxkczpEaWdlc3RWYWx1ZT5uU1lQOTZTMGtFT1RWdzJnVW91VVAvVStnWlk9PC9kczpEaWdlc3RWYWx1ZT48L2RzOlJlZmVyZW5jZT48L2RzOlNpZ25lZEluZm8+"
		"PGRzOlNpZ25hdHVyZVZhbHVlPlBObXpnTG1pU3hwS0FqSWE0TnN3OFNUQndLbHIreGcxd25YZzJHLy9uTGtLQUpMOEFiVlhzWktxTzFudFJCVmxkd3JzZlJTbFl6VXVYbGxFUmR2dlYxMUdSQkpaalRkek9MM0xwR0NVaUgxT2JYM3F3M3RxU1oxMUpaZWNabXFYQWdrd0RSQkx0SDA2NHBVdFF0L0E3dyt0TzMvOG1Nd2MrekIyeURjSWNZZytvMzJncDZwamFXY0o5SkZiOElWN29kLzRPTC9MWjdYOUFXRy9nR1VwYU1WZ1VXaFkvZlNxanFKTU4ya1g5Q3ZJUEMxbzJMWVNRQ1hWK1Y2OU9iM0J5MEhHY2JxRE9SbC94UWhBSytNbTc1TlhYRXE4b3ZldHNHcjJvcTlTcnQram9Wb2dkREJ4d1RZamVlQkIxZjBzTjdLYnBNWHhoVTFWNjZQQlgwRDZPdz09PC9kczpTaWduYXR1cm"
		"VWYWx1ZT48L2RzOlNpZ25hdHVyZT48L0F1dGhuUmVxdWVzdD4=", ENDITEM, 
		"Name=RelayState", "Value=oucrsiqwxzjqjqtzodewtitru", ENDITEM, 
		EXTRARES, 
		"Url=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_variation_0.pb", "Referer=", ENDITEM, 
		"Url=https://ssl.gstatic.com/safebrowsing/csd/client_model_v5_ext_variation_0.pb", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(25);

	web_submit_form("sso_2", 
		"Snapshot=t75.inf", 
		ITEMDATA, 
		"Name=j_username", "Value=p710801", ENDITEM, 
		"Name=j_password", "Value=Start123!", ENDITEM, 
		"Name=uidPasswordLogon", "Value=Log On", ENDITEM, 
		LAST);

	web_submit_form("diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com_2", 
		"Action=https://diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com/", 
		"Snapshot=t76.inf", 
		ITEMDATA, 
		EXTRARES, 
		"Url=/sap-ui-cachebuster", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/saptoolsets/common/plugin/ide/css/MainLayout.css", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/lib/requirejs/require.js", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/core/Global.js", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/core/Core-preload.js", ENDITEM, 
		"Url=/env.json", ENDITEM, 
		"Url=https://sapui5.hana.ondemand.com/1.46.7/resources/sap-ui-core.js", ENDITEM, 
		"Url=https://sapui5.hana.ondemand.com/1.46.7/resources/sap/ui/core/library-preload.js", ENDITEM, 
		"Url=https://sapui5.hana.ondemand.com/1.46.7/resources/sap/ui/table/library-preload.js", ENDITEM, 
		"Url=https://sapui5.hana.ondemand.com/1.46.7/resources/sap/ui/commons/library-preload.js", ENDITEM, 
		"Url=https://sapui5.hana.ondemand.com/1.46.7/resources/sap/ui/ux3/library-preload.js", ENDITEM, 
		"Url=https://sapui5.hana.ondemand.com/1.46.7/resources/sap/ui/unified/library-preload.js", ENDITEM, 
		"Url=https://sapui5.hana.ondemand.com/1.46.7/resources/sap/uxap/library-preload.js", ENDITEM, 
		"Url=https://sapui5.hana.ondemand.com/1.46.7/resources/sap/tnt/library-preload.js", ENDITEM, 
		"Url=https://sapui5.hana.ondemand.com/1.46.7/resources/sap/ui/layout/library-preload.js", ENDITEM, 
		"Url=https://sapui5.hana.ondemand.com/1.46.7/resources/sap/m/library-preload.js", ENDITEM, 
		"Url=https://sapui5.hana.ondemand.com/1.46.7/resources/sap/ui/comp/library-preload.js", ENDITEM, 
		"Url=https://sapui5.hana.ondemand.com/1.46.7/resources/sap/ui/fl/library-preload.js", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/ui/library-preload.json", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/m/themes/sap_flat/library.css", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/ui/library.js", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/ui/themes/sap_flat/library.css", ENDITEM, 
		"Url=https://sapui5.hana.ondemand.com/1.46.7/resources/sap/uxap/i18n/i18n.properties", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/uxap/themes/sap_flat/library.css", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/tnt/themes/sap_flat/library.css", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/ui/comp/themes/sap_flat/library.css", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/preload/themes/sap_flat/library.css", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/core/FeatureConfig.js", ENDITEM, 
		"Url=/di/profile", ENDITEM, 
		"Url=/di/profile/prefs/?filter=watt%2FuserEnabledFeatures%2F.%2A", ENDITEM, 
		"Url=/di/workspace/all", ENDITEM, 
		"Url=/di/project-type", ENDITEM, 
		"Url=/di/project/workspaceb6ejmqu0t9fiwmxv/tree/?depth=1", ENDITEM, 
		"Url=/api/listDestinations", ENDITEM, 
		"Url=/di/project/workspaceb6ejmqu0t9fiwmxv/MTA", ENDITEM, 
		"Url=/di/project/workspaceb6ejmqu0t9fiwmxv/tree/?depth=1000&includeFiles=true", ENDITEM, 
		"Url=/di/client/features", ENDITEM, 
		"Url=/javatoolsclient_w9b8ba97a/client/v2.0.0_1506385218314/config-preload.json", ENDITEM, 
		"Url=/resources/sap/watt/config-preload.json", ENDITEM, 
		"Url=/resources/sap/watt/config-preload.js", ENDITEM, 
		"Url=/resources/sap/watt/i18n/config-preload.js", ENDITEM, 
		"Url=/javatoolsclient_w9b8ba97a/client/v2.0.0_1506385218314/config-preload.js", ENDITEM, 
		"Url=/javatoolsclient_w9b8ba97a/client/v2.0.0_1506385218314/i18n/config-preload.js", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/ideplatform/plugin/run/ui/TitleExtendedControl.js", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/ideplatform/plugin/aceeditor/control/lib/ace-noconflict/ace.js", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/ideplatform/plugin/aceeditor/control/lib/ace-noconflict/ext-searchbox.js", ENDITEM, 
		"Url=https://sapui5.hana.ondemand.com/1.46.7/resources/sap/ui/core/messagebundle.properties", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/debug/core/Plugin.js", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/platform/plugin/console/view/Console.view.xml", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/che/plugin/chebackend/Plugin.js", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/ideplatform/debug/core/service/DebugPlatform.js", ENDITEM, 
		"Url=/resources/sap/watt/saptoolsets/ui5/project/plugin/servicecatalog/Plugin.js", ENDITEM, 
		"Url=/services/userapi/currentUser", ENDITEM, 
		"Url=/di/workspace/workspaceb6ejmqu0t9fiwmxv", ENDITEM, 
		"Url=https://sapui5.hana.ondemand.com/1.46.7/resources/sap/m/messagebundle.properties", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/ide/Plugin.js", ENDITEM, 
		"Url=/resources/sap/watt/platform/plugin/content/view/Content.view.xml", ENDITEM, 
		"Url=/resources/sap/watt/platform/plugin/content/control/EditorArea.js", ENDITEM, 
		"Url=https://sapui5.hana.ondemand.com/1.46.7/resources/sap/ui/table/messagebundle.properties", ENDITEM, 
		"Url=/resources/sap/watt/platform/plugin/runinnewprocess/css/PopupBlockerDialogStyles.css", ENDITEM, 
		"Url=/resources/sap/watt/platform/plugin/runinnewprocess/img/PopupBlockerChrome.gif", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/platform/plugin/toprightpane/view/TopRightPaneContainer.view.xml", ENDITEM, 
		"Url=/di/profile/prefs", ENDITEM, 
		"Url=/resources/sap/watt/platform/plugin/usernotification/css/userNotification.css", ENDITEM, 
		"Url=/resources/sap/watt/platform/plugin/perspective/css/perspective.css", ENDITEM, 
		"Url=/resources/sap/watt/platform/plugin/displayinformation/css/featuresinfo.css", ENDITEM, 
		"Url=/resources/sap/watt/platform/plugin/displayinformation/css/displayinformation.css", ENDITEM, 
		"Url=/resources/sap/watt/platform/plugin/toolbar/css/Toolbar.css", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/lib/mousetrap/mousetrap-global-bind.js", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/uitools/version.json", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/lib/mousetrap/mousetrap-record.js", ENDITEM, 
		"Url=/resources/sap/watt/platform/plugin/console/css/console.css", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/platform/plugin/repositorybrowser/view/RepositoryBrowser.view.xml", ENDITEM, 
		"Url=https://sapui5.hana.ondemand.com/1.46.7/resources/sap/ui/commons/messagebundle.properties", ENDITEM, 
		"Url=/resources/sap/watt/platform/plugin/content/css/content.css", ENDITEM, 
		"Url=/resources/sap/watt/platform/plugin/menu/css/LTRMenu.css", ENDITEM, 
		"Url=https://sapui5.hana.ondemand.com/1.46.7/resources/sap/ui/layout/messagebundle.properties", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/debug/core/command/ToggleDebugClientCommand.js", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/test/testresult/command/ToggleTestPartCommand.js", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/ideplatform/plugin/problemsView/css/problemsView.css", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/runconsole/css/runconsole.css", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/gitclient/css/gitClient.css", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/gitclient/css/gitFileSearch.css", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/gitclient/css/gitAmountIndicator.css", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/gitclient/css/gitToolbarButtons.css", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/gitclient/css/Controls-Table-Delta.css", ENDITEM, 
		"Url=/di/project/workspaceb6ejmqu0t9fiwmxv/MTA/Java", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/platform/plugin/perspective/command/AbstractUIPartToggler.js", ENDITEM, 
		"Url=/resources/sap/watt/common/plugin/builder/css/Builder.css", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/ideplatform/plugin/run/view/RunConfigurations.fragment.js", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/run/css/runConfigurationsStyles.css", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/ideplatform/che/plugin/chebackend/io/Request.js", ENDITEM, 
		"Url=/resources/sap/watt/platform/plugin/usernotificationbar/css/userNotificationBar.css", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/che/plugin/chebackend/service/ProjectTypeDAO_Consolidation.js", ENDITEM, 
		"Url=/resources/sap/watt/saptoolsets/runner/common/mockpreview/service/MockHtmlProducer.js", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/platform/plugin/document/Document.js", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/ideplatform/plugin/projectType/service/ProjectTypeMetadata.js", ENDITEM, 
		"Url=/di/", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/aceeditor/css/aceeditor.css", ENDITEM, 
		"Url=/di/project/workspaceb6ejmqu0t9fiwmxv/file/MTA/Java/src/main/java/com/company/MTA/Java/HelloServlet.java", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/intellisence/control/AutoCompletePopup.js", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/intellisence/control/AutoCompleteList.js", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/intellisence/control/AutoCompletePopover.js", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/intellisence/control/AutoCompleteItem.js", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/intellisence/css/intellisence.css", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/ideplatform/plugin/aceeditor/control/lib/ace-noconflict/mode-java.js", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/ideplatform/plugin/run/util/DocumentWindowsUtil.js", ENDITEM, 
		"Url=/resources/sap/watt/platform/plugin/tipsandtricks/css/TipsAndTricksDialogStyles.css", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/template/tips/TemplateFavoritesTip.js", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/keyboardShortcutsSetting/tips/DefineKeyboardShortcutsTip.js", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/hcpconnectivity/tips/LinkToCockpitTip.js", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/gitclient/tip/InitRepositoryTip.js", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/run/tips/HashFragmentTip.js", ENDITEM, 
		"Url=/resources/sap/watt/saptoolsets/fiori/project/plugin/fioriexttemplate/tips/OpenLayoutEditorFromExtPaneTip.js", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/aceeditor/tips/AutoSaveTip.js", ENDITEM, 
		"Url=https://sapui5.hana.ondemand.com/1.46.7/resources/sap/ui/core/themes/base/fonts/SAP-icons.woff2", ENDITEM, 
		"Url=/di/lsp/getStatus?workspaceId=workspaceb6ejmqu0t9fiwmxv", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/aceeditor/img/AutoSave.gif", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/ideplatform/plugin/aceeditor/themes/theme-sap-cumulus.js", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/ideplatform/plugin/runconsole/view/RunConsole.view.xml", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/ideplatform/plugin/runconsole/view/RunConsole.controller.js", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/ideplatform/plugin/welcomescreen/ui/view/WelcomeContent.view.xml", ENDITEM, 
		"Url=/resources/sap/watt/platform/plugin/pluginmanager/css/pluginManager.css", ENDITEM, 
		"Url=/resources/sap/watt/platform/plugin/jsonrpc2/service/JsonRpcProxy.js", ENDITEM, 
		"Url=/resources/sap/watt/ideplatform/plugin/welcomescreen/ui/css/welcomescreen.css", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/saptoolsets/fiori/common/plugin/welcomescreenimpl/helpfullinks.json", ENDITEM, 
		"Url=/di/project/workspaceb6ejmqu0t9fiwmxv/modules/MTA", ENDITEM, 
		"Url=/resources/sap/watt/platform/plugin/jsonrpc2/service/RpcBuilder.js", ENDITEM, 
		LAST);

	web_url("index.html", 
		"URL=https://diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com/index.html?1506424805906", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com/", 
		"Snapshot=t77.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("prefs", 
		"URL=https://diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com/di/profile/prefs", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com/", 
		"Snapshot=t78.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"watt/sap.watt.ideplatform.generationwizard.recentlyUsedTemplates/hanatemplates.hcpmtaproject\":1506423595523,\"watt/sap.watt.ideplatform.generationwizard.recentlyUsedTemplates/sap.xs.java.project.web.template\":1506423678463,\"watt/sap.watt.common.repositorybrowser.service.RepositoryBrowserPersistence/nodes\":\"[\\\"folder::workspace\\\",\\\"folder:/MTA:workspace\\\",\\\"folder:/MTA/Java:workspace\\\",\\\"folder:/MTA/Java/src:workspace\\\",\\\"folder:/MTA/Java/src/main:workspace\\\",\\\""
		"folder:/MTA/Java/src/main/java:workspace\\\"]\",\"watt/sap.watt.common.repositorybrowser.service.RepositoryBrowserPersistence/version\":1,\"watt/sap.watt.common.repositorybrowser.service.RepositoryBrowserPersistence/linked\":false,\"watt/sap.watt.common.repositorybrowser.service.RepositoryBrowserPersistence/selected\":\"file:/MTA/Java/src/main/java/com/company/MTA/Java/HelloServlet.java:workspace\",\"watt/sap.watt.common.service.ui.Perspective/development\":\"{\\\"content\\\":{\\\"left\\\":\\\""
		"repositorybrowser\\\",\\\"center_top\\\":\\\"content\\\",\\\"center_bottom\\\":\\\"console\\\"},\\\"left\\\":\\\"39.79193758127438%\\\",\\\"right\\\":\\\"hidden\\\",\\\"center_top\\\":\\\"70%\\\"}\",\"watt/sap.watt.common.service.ui.Perspective/_currentPerspective\":\"development\",\"watt/sap.watt.common.service.ui.Perspective/development_lastKnown\":\"{\\\"left\\\":\\\"39.79193758127438%\\\",\\\"center_top\\\":\\\"70%\\\"}\",\"watt/sap.watt.common.service.ui.Perspective/version\":1,\"watt/"
		"sap.watt.common.Monitoring/FioriCloudEditionUser\":false,\"watt/sap.watt.platform.plugin.notificationmanager.service.NotificationManager/messages\":\"[]\",\"watt/userEnabledFeatures/disabledFeatures\":\"[]\",\"watt/userEnabledFeatures/enabledFeatures\":\"[\\\"javatools\\\"]\",\"watt/sap.watt.common.content.service.ContentServicePersistence/activetab\":\"{\\\"editor\\\":\\\"aceeditor\\\",\\\"keystring\\\":\\\"file:/MTA/Java/src/main/java/com/company/MTA/Java/HelloServlet.java:workspace\\\"}\",\""
		"watt/sap.watt.common.content.service.ContentServicePersistence/version\":1,\"watt/sap.watt.common.content.service.ContentServicePersistence/tabs\":\"[{\\\"keystring\\\":\\\"file:/MTA/Java/src/main/java/com/company/MTA/Java/HelloServlet.java:workspace\\\",\\\"editor\\\":\\\"aceeditor\\\"}]\",\"watt/sap.watt.common.service.ui.WelcomeScreen/diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com\":\"{\\\"bIsVersionUpdate\\\":false,\\\"oVersionUpdate\\\":{\\\"from\\\":\\\"170928\\\",\\\"to\\\":\\\""
		"171012\\\"}}\",\"watt/sap.watt.ideplatform.generationwizard.sortMode/sortMode\":\"recentlyUsed\",\"watt/sap.watt.platform.filefilter.FileFilterHide/hidden\":true,\"watt/sap.watt.common.plugin.welcomescreen.service.Version/diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com\":\"v_171012\",\"watt/sap.watt.common.plugin.platform.service.keepalive.KeepAlive/nLastLogonTimestamp\":1506424820269}", 
		EXTRARES, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/ui/commons/themes/base/img/splitter/splitter_horiz_grip.gif", "Referer=https://diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/preload/themes/sap_flat/library.css", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/ui/commons/themes/base/img/toolbar/overflow.png", "Referer=https://diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/preload/themes/sap_flat/library.css", ENDITEM, 
		"Url=/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/ui/fonts/SAP-icons-watt.woff", "Referer=https://diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com/resources/~5cfddba6c4c93a9574da8795b231db9795ec15e1~/sap/watt/preload/themes/sap_flat/library.css", ENDITEM, 
		LAST);

	web_url("getHashedUser", 
		"URL=https://diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com/di/usageAnalytics/getHashedUser", 
		"Resource=0", 
		"Referer=https://diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com/", 
		"Snapshot=t79.inf", 
		"Mode=HTML", 
		LAST);

	web_url("diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com_3", 
		"URL=https://diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com/?rand=76629", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com/", 
		"Snapshot=t80.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/resources/sap/watt/platform/plugin/websocketconnectivity/service/WebsocketProxy.js", ENDITEM, 
		"Url=https://trackerexta90daed17.hana.ondemand.com/tracker/js/privacy.js", ENDITEM, 
		"Url=https://trackerexta90daed17.hana.ondemand.com/tracker/js/piwik.js", ENDITEM, 
		"Url=https://trackerexta90daed17.hana.ondemand.com/tracker/js/piwik_plugin.js", ENDITEM, 
		"Url=https://trackerexta90daed17.hana.ondemand.com/tracker/log?action_name=SAP%20Web%20IDE&idsite=7a7ab2fe-3cf9-4eab-892a-9dc80cad0ca5&rec=1&r=520058&h=14&m=20&s=36&url=https%3A%2F%2Fdiperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com%2F&urlref=http%3A%2F%2F10.26.156.125%3A50000%2Fsaml2%2Fidp%2Fsso&_id=0e4748b96fafa5d6&_idts=1506424836&_idvc=1&_idn=1&_refts=1506424836&_viewts=1506424836&_ref=http%3A%2F%2F10.26.156.125%3A50000%2Fsaml2%2Fidp%2Fsso&send_image=0&pdf=1&qt=0&realp=0&wma=0&dir=0&fla=0&"
		"java=0&gears=0&ag=0&cookie=1&res=1630x983&gt_ms=75&timezone=-180&locale=en-US&pageTitle=SAP+Web+IDE&pageWidth=1630&pageHeight=877&custom1=unhandledError&custom2=USAGE&custom3=NONE_SAP&custom4=&custom5=&custom6=171012&custom7=CANARY&custom8=&custom9=&custom10=wf1f52214&custom11=&element_type=page&event_type=load", ENDITEM, 
		"Url=https://trackerexta90daed17.hana.ondemand.com/tracker/log?e_c=ide_module&e_a=sap.watt.ideplatform.languageserverprotocol%2Fservice%2FLSPDocumentAdapter&idsite=7a7ab2fe-3cf9-4eab-892a-9dc80cad0ca5&rec=1&r=348128&h=14&m=20&s=37&url=https%3A%2F%2Fdiperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com%2F&urlref=http%3A%2F%2F10.26.156.125%3A50000%2Fsaml2%2Fidp%2Fsso&_id=0e4748b96fafa5d6&_idts=1506424836&_idvc=1&_idn=0&_refts=1506424836&_viewts=1506424836&_ref="
		"http%3A%2F%2F10.26.156.125%3A50000%2Fsaml2%2Fidp%2Fsso&send_image=0&pdf=1&qt=0&realp=0&wma=0&dir=0&fla=0&java=0&gears=0&ag=0&cookie=1&res=1630x983&gt_ms=75&timezone=-180&locale=en-US&pageTitle=SAP+Web+IDE&pageWidth=1630&pageHeight=877&custom1=serviceTimeout&custom2=USAGE&custom3=NONE_SAP&custom4=method&custom5=onTabSelected&custom6=171012&custom7=CANARY&custom8=&custom9=&custom10=wf1f52214&custom11=&event_type=custom&element_type=event", ENDITEM, 
		"Url=https://trackerexta90daed17.hana.ondemand.com/tracker/log?e_c=ide_module&e_a=sap.watt.ideplatform.languageserverprotocol%2Fservice%2FLSPManager&idsite=7a7ab2fe-3cf9-4eab-892a-9dc80cad0ca5&rec=1&r=515656&h=14&m=20&s=38&url=https%3A%2F%2Fdiperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com%2F&urlref=http%3A%2F%2F10.26.156.125%3A50000%2Fsaml2%2Fidp%2Fsso&_id=0e4748b96fafa5d6&_idts=1506424836&_idvc=1&_idn=0&_refts=1506424836&_viewts=1506424836&_ref="
		"http%3A%2F%2F10.26.156.125%3A50000%2Fsaml2%2Fidp%2Fsso&send_image=0&pdf=1&qt=0&realp=0&wma=0&dir=0&fla=0&java=0&gears=0&ag=0&cookie=1&res=1630x983&gt_ms=75&timezone=-180&locale=en-US&pageTitle=SAP+Web+IDE&pageWidth=1630&pageHeight=877&custom1=serviceTimeout&custom2=USAGE&custom3=NONE_SAP&custom4=method&custom5=getControllerInstance&custom6=171012&custom7=CANARY&custom8=&custom9=&custom10=wf1f52214&custom11=&event_type=custom&element_type=event", ENDITEM, 
		"Url=https://trackerexta90daed17.hana.ondemand.com/tracker/log?e_c=ide_OptionalFeatureLoaded&e_a=Tools%20for%20Java%20Development&idsite=7a7ab2fe-3cf9-4eab-892a-9dc80cad0ca5&rec=1&r=672403&h=14&m=20&s=44&url=https%3A%2F%2Fdiperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com%2F&urlref=http%3A%2F%2F10.26.156.125%3A50000%2Fsaml2%2Fidp%2Fsso&_id=0e4748b96fafa5d6&_idts=1506424836&_idvc=1&_idn=0&_refts=1506424836&_viewts=1506424836&_ref=http%3A%2F%2F10.26.156.125%3A50000%2Fsaml2%2Fidp%2Fsso&send_image=0"
		"&pdf=1&qt=0&realp=0&wma=0&dir=0&fla=0&java=0&gears=0&ag=0&cookie=1&res=1630x983&gt_ms=75&timezone=-180&locale=en-US&pageTitle=SAP+Web+IDE&pageWidth=1630&pageHeight=877&custom1=serviceTimeout&custom2=USAGE&custom3=NONE_SAP&custom4=method&custom5=getControllerInstance&custom6=171012&custom7=CANARY&custom8=&custom9=&custom10=wf1f52214&custom11=&event_type=custom&element_type=event", ENDITEM, 
		"Url=https://trackerexta90daed17.hana.ondemand.com/tracker/log?e_c=ide_module&e_a=sap.watt.platform.jsonrpc2%2Fservice%2FJsonRpcProxy&idsite=7a7ab2fe-3cf9-4eab-892a-9dc80cad0ca5&rec=1&r=494746&h=14&m=20&s=44&url=https%3A%2F%2Fdiperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com%2F&urlref=http%3A%2F%2F10.26.156.125%3A50000%2Fsaml2%2Fidp%2Fsso&_id=0e4748b96fafa5d6&_idts=1506424836&_idvc=1&_idn=0&_refts=1506424836&_viewts=1506424836&_ref=http%3A%2F%2F10.26.156.125%3A50000%2Fsaml2%2Fidp%2Fsso&"
		"send_image=0&pdf=1&qt=0&realp=0&wma=0&dir=0&fla=0&java=0&gears=0&ag=0&cookie=1&res=1630x983&gt_ms=75&timezone=-180&locale=en-US&pageTitle=SAP+Web+IDE&pageWidth=1630&pageHeight=877&custom1=serviceTimeout&custom2=USAGE&custom3=NONE_SAP&custom4=method&custom5=&custom6=171012&custom7=CANARY&custom8=&custom9=&custom10=wf1f52214&custom11=&event_type=custom&element_type=event", ENDITEM, 
		"Url=https://trackerexta90daed17.hana.ondemand.com/tracker/log?e_c=ide_module&e_a=sap.watt.platform.websocketconnectivity%2Fservice%2FWebsocketProxy&idsite=7a7ab2fe-3cf9-4eab-892a-9dc80cad0ca5&rec=1&r=612404&h=14&m=20&s=44&url=https%3A%2F%2Fdiperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com%2F&urlref=http%3A%2F%2F10.26.156.125%3A50000%2Fsaml2%2Fidp%2Fsso&_id=0e4748b96fafa5d6&_idts=1506424836&_idvc=1&_idn=0&_refts=1506424836&_viewts=1506424836&_ref="
		"http%3A%2F%2F10.26.156.125%3A50000%2Fsaml2%2Fidp%2Fsso&send_image=0&pdf=1&qt=0&realp=0&wma=0&dir=0&fla=0&java=0&gears=0&ag=0&cookie=1&res=1630x983&gt_ms=75&timezone=-180&locale=en-US&pageTitle=SAP+Web+IDE&pageWidth=1630&pageHeight=877&custom1=serviceTimeout&custom2=USAGE&custom3=NONE_SAP&custom4=method&custom5=&custom6=171012&custom7=CANARY&custom8=&custom9=&custom10=wf1f52214&custom11=&event_type=custom&element_type=event", ENDITEM, 
		"Url=https://trackerexta90daed17.hana.ondemand.com/tracker/log?e_c=ide_filepath&e_a=unknown&idsite=7a7ab2fe-3cf9-4eab-892a-9dc80cad0ca5&rec=1&r=263565&h=14&m=20&s=44&url=https%3A%2F%2Fdiperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com%2F&urlref=http%3A%2F%2F10.26.156.125%3A50000%2Fsaml2%2Fidp%2Fsso&_id=0e4748b96fafa5d6&_idts=1506424836&_idvc=1&_idn=0&_refts=1506424836&_viewts=1506424836&_ref=http%3A%2F%2F10.26.156.125%3A50000%2Fsaml2%2Fidp%2Fsso&send_image=0&pdf=1&qt=0&realp=0&wma=0&dir=0&fla=0&"
		"java=0&gears=0&ag=0&cookie=1&res=1630x983&gt_ms=75&timezone=-180&locale=en-US&pageTitle=SAP+Web+IDE&pageWidth=1630&pageHeight=877&custom1=serviceTimeout&custom2=USAGE&custom3=NONE_SAP&custom4=method&custom5=&custom6=171012&custom7=CANARY&custom8=&custom9=&custom10=wf1f52214&custom11=&event_type=custom&element_type=event", ENDITEM, 
		LAST);

	web_add_cookie("_pk_id.7a7ab2fe-3cf9-4eab-892a-9dc80cad0ca5.0079=b2fa415490fbaa29.1506424836.0.1506424836..; DOMAIN=diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com");

	web_add_cookie("_swa_ref.7a7ab2fe-3cf9-4eab-892a-9dc80cad0ca5.0079=%5B%22%22%2C%22%22%2C1506424836%2C%22http%3A%2F%2F10.26.156.125%3A50000%2Fsaml2%2Fidp%2Fsso%22%5D; DOMAIN=diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com");

	web_add_cookie("_swa_id.7a7ab2fe-3cf9-4eab-892a-9dc80cad0ca5.0079=0e4748b96fafa5d6.1506424836.1.1506424845.1506424836.; DOMAIN=diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com");

	web_add_cookie("_swa_ses.7a7ab2fe-3cf9-4eab-892a-9dc80cad0ca5.0079=*; DOMAIN=diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com");

	web_custom_request("prefs_2", 
		"URL=https://diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com/di/profile/prefs", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com/", 
		"Snapshot=t81.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"watt/sap.watt.ideplatform.generationwizard.recentlyUsedTemplates/hanatemplates.hcpmtaproject\":1506423595523,\"watt/sap.watt.ideplatform.generationwizard.recentlyUsedTemplates/sap.xs.java.project.web.template\":1506423678463,\"watt/sap.watt.common.repositorybrowser.service.RepositoryBrowserPersistence/version\":1,\"watt/sap.watt.common.repositorybrowser.service.RepositoryBrowserPersistence/nodes\":\"[\\\"folder::workspace\\\",\\\"folder:/MTA:workspace\\\",\\\"folder:/MTA/Java/src"
		":workspace\\\",\\\"folder:/MTA/Java/src/main:workspace\\\",\\\"folder:/MTA/Java/src/main/java:workspace\\\",\\\"folder:/MTA/Java:workspace\\\"]\",\"watt/sap.watt.common.repositorybrowser.service.RepositoryBrowserPersistence/selected\":\"folder::workspace\",\"watt/sap.watt.common.repositorybrowser.service.RepositoryBrowserPersistence/linked\":false,\"watt/sap.watt.common.service.ui.Perspective/development\":\"{\\\"content\\\":{\\\"left\\\":\\\"repositorybrowser\\\",\\\"center_top\\\":\\\"content\\"
		"\",\\\"center_bottom\\\":\\\"console\\\"},\\\"left\\\":\\\"39.79193758127438%\\\",\\\"right\\\":\\\"hidden\\\",\\\"center_top\\\":\\\"70%\\\"}\",\"watt/sap.watt.common.service.ui.Perspective/_currentPerspective\":\"development\",\"watt/sap.watt.common.service.ui.Perspective/development_lastKnown\":\"{\\\"left\\\":\\\"39.79193758127438%\\\",\\\"center_top\\\":\\\"70%\\\"}\",\"watt/sap.watt.common.service.ui.Perspective/version\":1,\"watt/sap.watt.common.Monitoring/FioriCloudEditionUser\":false,\""
		"watt/sap.watt.platform.plugin.notificationmanager.service.NotificationManager/messages\":\"[]\",\"watt/userEnabledFeatures/disabledFeatures\":\"[]\",\"watt/userEnabledFeatures/enabledFeatures\":\"[\\\"javatools\\\"]\",\"watt/sap.watt.common.content.service.ContentServicePersistence/activetab\":\"{\\\"editor\\\":\\\"aceeditor\\\",\\\"keystring\\\":\\\"file:/MTA/Java/src/main/java/com/company/MTA/Java/HelloServlet.java:workspace\\\"}\",\"watt/sap.watt.common.content.service.ContentServicePersistence"
		"/version\":1,\"watt/sap.watt.common.content.service.ContentServicePersistence/tabs\":\"[{\\\"keystring\\\":\\\"file:/MTA/Java/src/main/java/com/company/MTA/Java/HelloServlet.java:workspace\\\",\\\"editor\\\":\\\"aceeditor\\\"}]\",\"watt/sap.watt.common.service.ui.WelcomeScreen/diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com\":\"{\\\"bIsVersionUpdate\\\":false,\\\"oVersionUpdate\\\":{\\\"from\\\":\\\"170928\\\",\\\"to\\\":\\\"171012\\\"}}\",\"watt/"
		"sap.watt.ideplatform.generationwizard.sortMode/sortMode\":\"recentlyUsed\",\"watt/sap.watt.platform.filefilter.FileFilterHide/hidden\":true,\"watt/sap.watt.common.plugin.welcomescreen.service.Version/diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com\":\"v_171012\",\"watt/sap.watt.common.plugin.platform.service.keepalive.KeepAlive/nLastLogonTimestamp\":1506424820269}", 
		LAST);

	web_url("diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com_4", 
		"URL=https://diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com/?rand=86346", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com/", 
		"Snapshot=t82.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://trackerexta90daed17.hana.ondemand.com/tracker/log?e_c=ide_filepath&e_a=unknown&idsite=7a7ab2fe-3cf9-4eab-892a-9dc80cad0ca5&rec=1&r=271718&h=14&m=21&s=8&url=https%3A%2F%2Fdiperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com%2F&urlref=http%3A%2F%2F10.26.156.125%3A50000%2Fsaml2%2Fidp%2Fsso&_id=0e4748b96fafa5d6&_idts=1506424836&_idvc=1&_idn=0&_refts=1506424836&_viewts=1506424836&_ref=http%3A%2F%2F10.26.156.125%3A50000%2Fsaml2%2Fidp%2Fsso&send_image=0&pdf=1&qt=0&realp=0&wma=0&dir=0&fla=0&"
		"java=0&gears=0&ag=0&cookie=1&res=1630x983&gt_ms=75&timezone=-180&locale=en-US&pageTitle=SAP+Web+IDE&pageWidth=1630&pageHeight=877&custom1=unhandledError&custom2=USAGE&custom3=NONE_SAP&custom4=&custom5=&custom6=171012&custom7=CANARY&custom8=&custom9=&custom10=wf1f52214&custom11=&event_type=custom&element_type=event", ENDITEM, 
		LAST);

	web_add_cookie("_swa_id.7a7ab2fe-3cf9-4eab-892a-9dc80cad0ca5.0079=0e4748b96fafa5d6.1506424836.1.1506424868.1506424836.; DOMAIN=diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com");

	web_custom_request("prefs_3", 
		"URL=https://diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com/di/profile/prefs", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com/", 
		"Snapshot=t83.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"watt/sap.watt.ideplatform.generationwizard.recentlyUsedTemplates/hanatemplates.hcpmtaproject\":1506423595523,\"watt/sap.watt.ideplatform.generationwizard.recentlyUsedTemplates/sap.xs.java.project.web.template\":1506423678463,\"watt/sap.watt.common.repositorybrowser.service.RepositoryBrowserPersistence/version\":1,\"watt/sap.watt.common.repositorybrowser.service.RepositoryBrowserPersistence/nodes\":\"[\\\"folder::workspace\\\",\\\"folder:/MTA:workspace\\\",\\\"folder:/MTA/Java/src"
		":workspace\\\",\\\"folder:/MTA/Java/src/main:workspace\\\",\\\"folder:/MTA/Java/src/main/java:workspace\\\",\\\"folder:/MTA/Java:workspace\\\"]\",\"watt/sap.watt.common.repositorybrowser.service.RepositoryBrowserPersistence/selected\":\"folder::workspace\",\"watt/sap.watt.common.repositorybrowser.service.RepositoryBrowserPersistence/linked\":false,\"watt/sap.watt.common.service.ui.Perspective/development\":\"{\\\"content\\\":{\\\"left\\\":\\\"repositorybrowser\\\",\\\"center_top\\\":\\\"content\\"
		"\",\\\"center_bottom\\\":\\\"console\\\"},\\\"left\\\":\\\"39.79193758127438%\\\",\\\"right\\\":\\\"hidden\\\",\\\"center_top\\\":\\\"70%\\\"}\",\"watt/sap.watt.common.service.ui.Perspective/_currentPerspective\":\"development\",\"watt/sap.watt.common.service.ui.Perspective/development_lastKnown\":\"{\\\"left\\\":\\\"39.79193758127438%\\\",\\\"center_top\\\":\\\"70%\\\"}\",\"watt/sap.watt.common.service.ui.Perspective/version\":1,\"watt/sap.watt.common.Monitoring/FioriCloudEditionUser\":false,\""
		"watt/sap.watt.platform.plugin.notificationmanager.service.NotificationManager/messages\":\"[]\",\"watt/userEnabledFeatures/disabledFeatures\":\"[]\",\"watt/userEnabledFeatures/enabledFeatures\":\"[\\\"javatools\\\"]\",\"watt/sap.watt.common.content.service.ContentServicePersistence/activetab\":\"{\\\"editor\\\":\\\"aceeditor\\\",\\\"keystring\\\":\\\"file:/MTA/Java/src/main/java/com/company/MTA/Java/HelloServlet.java:workspace\\\"}\",\"watt/sap.watt.common.content.service.ContentServicePersistence"
		"/version\":1,\"watt/sap.watt.common.content.service.ContentServicePersistence/tabs\":\"[{\\\"keystring\\\":\\\"file:/MTA/Java/src/main/java/com/company/MTA/Java/HelloServlet.java:workspace\\\",\\\"editor\\\":\\\"aceeditor\\\"}]\",\"watt/sap.watt.common.service.ui.WelcomeScreen/diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com\":\"{\\\"bIsVersionUpdate\\\":false,\\\"oVersionUpdate\\\":{\\\"from\\\":\\\"170928\\\",\\\"to\\\":\\\"171012\\\"}}\",\"watt/"
		"sap.watt.ideplatform.generationwizard.sortMode/sortMode\":\"recentlyUsed\",\"watt/sap.watt.platform.filefilter.FileFilterHide/hidden\":true,\"watt/sap.watt.common.plugin.welcomescreen.service.Version/diperf-wf1f52214.dispatcher.int.sap.hana.ondemand.com\":\"v_171012\",\"watt/sap.watt.common.plugin.platform.service.keepalive.KeepAlive/nLastLogonTimestamp\":1506424820269,\"watt/sap.watt.platform.tipsandtricks.service.tipsandtricks/showonstartup\":false}", 
		LAST);

	return 0;
}